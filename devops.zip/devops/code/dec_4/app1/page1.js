// load the selenium webdriver
const webdriver = require('selenium-webdriver')

async function test1() {
    // open the browser
    const driver = new webdriver.Builder().forBrowser('chrome').build()

    // go to google.com
    await driver.get('https://google.com')

    // close the browser
    driver.close()
}

// test1()

async function test2() {
    const driver = new webdriver.Builder().forBrowser('chrome').build()

    await driver.get('https://google.com')

    // find input with name = 'q'
    const input = await driver.findElement(webdriver.By.name('q'))

    // enter a text 'iphone 11 pro'
    await input.sendKeys('iPhone 11 pro', webdriver.Key.ENTER)

    driver.close()
}

test2()