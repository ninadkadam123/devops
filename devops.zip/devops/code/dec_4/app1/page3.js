const webdriver = require('selenium-webdriver')
const By = webdriver.By

async function testAll() {
    // expected
    const value1 = 20, value2 = 20
    const expectedAddition = 40
    const expectedSubtraction = 0
    const expectedMultiplication = 400
    const expectedDivision = 1

    const driver = new webdriver.Builder().forBrowser('chrome').build()
    await driver.get('file:///Volumes/Data/DAC/asdm/code/dec_4/app1/calculatorV2.html')

    await driver.findElement(By.id('value1')).sendKeys(value1)
    await driver.findElement(By.id('value2')).sendKeys(value2)

    // addition
    await driver.findElement(By.id('addition')).click()
    await driver.findElement(By.id('button-calculate')).click()
    const actualAddition = await driver.findElement(By.id('result')).getAttribute('value')
    if (expectedAddition == actualAddition) {
        console.log('addition: Yes')
    } else {
        console.log('addition: No')
    }

    // subtraction
    await driver.findElement(By.id('subtraction')).click()
    await driver.findElement(By.id('button-calculate')).click()
    const actualSubtraction = await driver.findElement(By.id('result')).getAttribute('value')
    if (expectedSubtraction == actualSubtraction) {
        console.log('subtraction: Yes')
    } else {
        console.log('subtraction: No')
    }

    // multiplication
    await driver.findElement(By.id('multiplication')).click()
    await driver.findElement(By.id('button-calculate')).click()
    const actualMultiplication = await driver.findElement(By.id('result')).getAttribute('value')
    if (expectedMultiplication == actualMultiplication) {
        console.log('multiplication: Yes')
    } else {
        console.log('multiplication: No')
    }

    // division
    await driver.findElement(By.id('division')).click()
    await driver.findElement(By.id('button-calculate')).click()
    const actualDivision = await driver.findElement(By.id('result')).getAttribute('value')
    if (expectedDivision == actualDivision) {
        console.log('division: Yes')
    } else {
        console.log('division: No')
    }

    driver.close()
}

testAll()