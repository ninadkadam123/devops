const crypto = require('crypto-js')

const password = 'test1234'
console.log('plain text password: ', password)

const encryptedPassword = crypto.MD5(password)
console.log('encrypte password: ' + encryptedPassword)
