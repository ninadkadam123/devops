const webdriver = require('selenium-webdriver')
const fs = require('fs')
const By = webdriver.By

async function scrapeTemperatures() {
    const data = []
    const driver = new webdriver.Builder().forBrowser('chrome').build()
    await driver.get('https://weather.com/en-IN/weather/tenday/l/cc4e93311b537126218a1d9a0dc33295fd3f3d0c8fe0965a4b8eab0fb00e7d39')

    let str = '['

    const table = await driver.findElement(By.className('twc-table'))
    const tbody = await table.findElement(By.tagName('tbody'))
    const trElements = await tbody.findElements(By.tagName('tr'))
    for (let index = 0; index < trElements.length; index++) {
        const tr = trElements[index]
        const tdElements = await tr.findElements(By.tagName('td'))

        const date = await tdElements[1].getText().replace('\n', '')
        const description = await tdElements[2].getText()
        const temperature = await tdElements[3].getText()
        const precip = await tdElements[4].getText()
        const wind = await tdElements[5].getText()
        const humidity = await tdElements[6].getText()
        
        data.push({
            date: date,
            description: description,
            temperature: temperature,
            precip: precip,
            wind: wind,
            humidity: humidity
        })

        str += `
            {
                "date": "${date}",
                "description": "${description}",
                "temperature": "${temperature}",
                "precip": "${precip}",
                "wind": "${wind}",
                "humidity": "${humidity}"
            },
        `
    }

    str += ']'

    console.log(str)


    driver.close()
    fs.writeFileSync('./temperatures.json', str)
}

scrapeTemperatures()